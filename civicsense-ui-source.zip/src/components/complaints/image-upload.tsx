
"use client";

import { useRef, useState } from "react";
import { ImagePlus, X, Upload, LoaderCircle } from "lucide-react";
import { auth } from "@/lib/firebase/client";

export interface UploadedImage {
  publicId: string;
}

interface ImageUploadProps {
  image: UploadedImage | null;
  onImageChange: (image: UploadedImage | null) => void;
}

const MAX_SIZE = 5 * 1024 * 1024;

const ALLOWED_TYPES = [
  "image/jpeg",
  "image/png",
  "image/webp",
];

export default function ImageUpload({
  image,
  onImageChange,
}: ImageUploadProps) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [preview, setPreview] = useState("");
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState("");

  async function handleUpload(file?: File) {
    if (!file) return;

    setError("");

    if (!ALLOWED_TYPES.includes(file.type)) {
      setError("Only JPG, PNG and WebP images are supported.");
      return;
    }

    if (file.size > MAX_SIZE) {
      setError("Image must be smaller than 5 MB.");
      return;
    }

    setUploading(true);

    try {
      const token = await auth.currentUser?.getIdToken();

      if (!token) {
        throw new Error("Please sign in again.");
      }

      const signatureResponse = await fetch(
        "/api/cloudinary/signature",
        {
          method: "POST",
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      const signatureData = await signatureResponse.json();

      if (!signatureResponse.ok) {
        throw new Error(
          signatureData.error ?? "Upload authorization failed."
        );
      }

      const formData = new FormData();

      formData.append("file", file);
      formData.append("api_key", signatureData.apiKey);
      formData.append("timestamp", String(signatureData.timestamp));
      formData.append("folder", signatureData.folder);
      formData.append("public_id", signatureData.publicId);
      formData.append("signature", signatureData.signature);

      const uploadResponse = await fetch(
        `https://api.cloudinary.com/v1_1/${signatureData.cloudName}/image/upload`,
        {
          method: "POST",
          body: formData,
        }
      );

      const uploadData = await uploadResponse.json();

      if (!uploadResponse.ok) {
        throw new Error(
          uploadData.error?.message ?? "Cloudinary upload failed."
        );
      }

      setPreview(uploadData.secure_url);

      onImageChange({
        publicId: uploadData.public_id,
      });
    } catch (err) {
      setError(
        err instanceof Error ? err.message : "Image upload failed."
      );
    } finally {
      setUploading(false);
    }
  }

  function removeImage() {
    onImageChange(null);
    setPreview("");
    setError("");

    if (inputRef.current) {
      inputRef.current.value = "";
    }
  }

  return (
    <div>
      <label className="mb-2 block text-sm font-medium text-slate-300">
        Attach a photograph (optional)
      </label>

      <input
        ref={inputRef}
        type="file"
        accept="image/jpeg,image/png,image/webp"
        className="hidden"
        onChange={(event) => {
          void handleUpload(event.target.files?.[0]);
        }}
      />

      {!image ? (
        <button
          type="button"
          disabled={uploading}
          onClick={() => inputRef.current?.click()}
          className="flex w-full items-center justify-center gap-3 rounded-xl border border-dashed border-white/20 bg-[#080d18] px-4 py-8 text-sm text-slate-400 transition hover:border-blue-500 hover:text-blue-300 disabled:opacity-50"
        >
          {uploading ? (
            <LoaderCircle className="animate-spin" size={22} />
          ) : (
            <ImagePlus size={22} />
          )}

          {uploading ? "Uploading image..." : "Choose an image"}
        </button>
      ) : (
        <div className="relative overflow-hidden rounded-xl border border-white/10">
          {preview && (
            <img
              src={preview}
              alt="Complaint attachment preview"
              className="max-h-64 w-full object-contain"
            />
          )}

          <button
            type="button"
            onClick={removeImage}
            className="absolute right-3 top-3 rounded-full bg-black/70 p-2 text-white hover:bg-red-600"
            aria-label="Remove image"
          >
            <X size={17} />
          </button>

          <div className="flex items-center gap-2 bg-[#080d18] p-3 text-sm text-emerald-300">
            <Upload size={16} />
            Image uploaded successfully
          </div>
        </div>
      )}

      <p className="mt-2 text-xs text-slate-500">
        JPG, PNG or WebP · Maximum 5 MB
      </p>

      {error && (
        <p className="mt-2 text-sm text-red-400">{error}</p>
      )}
    </div>
  );
}
