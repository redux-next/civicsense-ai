
"use client";

import { useEffect, useState, type FormEvent } from "react";
import { useRouter } from "next/navigation";
import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  updateProfile,
} from "firebase/auth";
import { ShieldCheck, LockKeyhole, Mail, UserRound } from "lucide-react";

import { auth } from "@/lib/firebase/client";
import { useAuth } from "@/components/auth/auth-provider";

export default function LoginPage() {
  const router = useRouter();
  const { user, loading } = useAuth();

  const [isRegister, setIsRegister] = useState(false);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (!loading && user) {
      router.replace("/dashboard");
    }
  }, [user, loading, router]);

  async function saveProfile() {
    const token = await auth.currentUser?.getIdToken(true);

    if (!token) {
      throw new Error("Unable to verify your account.");
    }

    const response = await fetch("/api/users/profile", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });

    if (!response.ok) {
      throw new Error("Your account was created, but profile setup failed. Please sign in again.");
    }
  }

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError("");
    setSubmitting(true);

    try {
      if (isRegister) {
        if (name.trim().length < 2) {
          throw new Error("Please enter your full name.");
        }

        const credential = await createUserWithEmailAndPassword(
          auth,
          email.trim(),
          password
        );

        await updateProfile(credential.user, {
          displayName: name.trim(),
        });

        await saveProfile();
      } else {
        await signInWithEmailAndPassword(
          auth,
          email.trim(),
          password
        );

        await saveProfile();
      }

      router.replace("/dashboard");
    } catch (err) {
      const message =
        err instanceof Error ? err.message : "Something went wrong.";

      setError(message);
    } finally {
      setSubmitting(false);
    }
  }

  if (loading || user) {
    return (
      <main className="flex min-h-screen items-center justify-center bg-[#080d18] text-white">
        Loading CivicSense...
      </main>
    );
  }

  return (
    <main className="flex min-h-screen items-center justify-center bg-[#080d18] px-5 py-12 text-white">
      <div className="grid w-full max-w-5xl overflow-hidden rounded-3xl border border-white/10 bg-[#101827] shadow-2xl md:grid-cols-2">
        <section className="hidden flex-col justify-between bg-gradient-to-br from-blue-700 to-indigo-950 p-12 md:flex">
          <div>
            <div className="mb-10 flex items-center gap-3">
              <div className="rounded-xl bg-white/15 p-3">
                <ShieldCheck size={28} />
              </div>
              <span className="text-2xl font-bold">CivicSense AI</span>
            </div>

            <h1 className="text-4xl font-bold leading-tight">
              Make your campus a better place.
            </h1>

            <p className="mt-5 leading-7 text-blue-100">
              Report campus issues, track their progress, and help build
              a smarter, more responsive university.
            </p>
          </div>

          <p className="text-sm text-blue-200">
            Assamese + English · AI-powered campus issue management
          </p>
        </section>

        <section className="p-7 sm:p-12">
          <div className="mb-8 md:hidden">
            <div className="mb-3 inline-flex rounded-xl bg-blue-500/15 p-3 text-blue-400">
              <ShieldCheck size={28} />
            </div>
            <h1 className="text-2xl font-bold">CivicSense AI</h1>
          </div>

          <h2 className="text-3xl font-bold">
            {isRegister ? "Create account" : "Welcome back"}
          </h2>

          <p className="mt-2 text-sm text-slate-400">
            {isRegister
              ? "Join CivicSense and make your voice heard."
              : "Sign in to access your campus dashboard."}
          </p>

          <form onSubmit={handleSubmit} className="mt-8 space-y-5">
            {isRegister && (
              <div>
                <label className="mb-2 block text-sm text-slate-300">
                  Full name
                </label>
                <div className="flex items-center rounded-xl border border-white/10 bg-[#080d18] px-4">
                  <UserRound size={18} className="text-slate-500" />
                  <input
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Your name"
                    className="w-full bg-transparent px-3 py-3.5 outline-none"
                  />
                </div>
              </div>
            )}

            <div>
              <label className="mb-2 block text-sm text-slate-300">
                Email address
              </label>
              <div className="flex items-center rounded-xl border border-white/10 bg-[#080d18] px-4">
                <Mail size={18} className="text-slate-500" />
                <input
                  required
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@example.com"
                  className="w-full bg-transparent px-3 py-3.5 outline-none"
                />
              </div>
            </div>

            <div>
              <label className="mb-2 block text-sm text-slate-300">
                Password
              </label>
              <div className="flex items-center rounded-xl border border-white/10 bg-[#080d18] px-4">
                <LockKeyhole size={18} className="text-slate-500" />
                <input
                  required
                  type="password"
                  minLength={6}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="At least 6 characters"
                  className="w-full bg-transparent px-3 py-3.5 outline-none"
                />
              </div>
            </div>

            {error && (
              <p className="rounded-xl border border-red-500/20 bg-red-500/10 p-3 text-sm text-red-300">
                {error}
              </p>
            )}

            <button
              disabled={submitting}
              className="w-full rounded-xl bg-blue-600 py-3.5 font-semibold transition hover:bg-blue-500 disabled:cursor-not-allowed disabled:opacity-60"
            >
              {submitting
                ? "Please wait..."
                : isRegister
                  ? "Create account"
                  : "Sign in"}
            </button>
          </form>

          <p className="mt-7 text-center text-sm text-slate-400">
            {isRegister
              ? "Already have an account?"
              : "Don't have an account?"}{" "}
            <button
              type="button"
              onClick={() => {
                setIsRegister(!isRegister);
                setError("");
              }}
              className="font-semibold text-blue-400 hover:text-blue-300"
            >
              {isRegister ? "Sign in" : "Register"}
            </button>
          </p>
        </section>
      </div>
    </main>
  );
}
