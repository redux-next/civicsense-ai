
"use client";

import {
  useCallback,
  useEffect,
  useState,
  type FormEvent,
  type ReactNode,
} from "react";
import { useRouter } from "next/navigation";
import { signOut } from "firebase/auth";
import {
  AlertCircle,
  CheckCircle2,
  Clock3,
  FileText,
  LogOut,
  MapPin,
  PlusCircle,
  RefreshCw,
  Send,
  ShieldCheck,
  Sparkles,
  Image as ImageIcon,
} from "lucide-react";

import { auth } from "@/lib/firebase/client";
import { useAuth } from "@/components/auth/auth-provider";
import ImageUpload, {
  type UploadedImage,
} from "@/components/complaints/image-upload";

import type {
  Complaint,
  ComplaintLanguage,
  ComplaintStatus,
} from "@/types/complaint";

const statusLabels: Record<ComplaintStatus, string> = {
  submitted: "Submitted",
  under_review: "Under review",
  in_progress: "In progress",
  resolved: "Resolved",
  rejected: "Rejected",
};

const statusStyles: Record<ComplaintStatus, string> = {
  submitted: "bg-blue-500/10 text-blue-300 border-blue-500/20",
  under_review: "bg-amber-500/10 text-amber-300 border-amber-500/20",
  in_progress: "bg-purple-500/10 text-purple-300 border-purple-500/20",
  resolved: "bg-emerald-500/10 text-emerald-300 border-emerald-500/20",
  rejected: "bg-red-500/10 text-red-300 border-red-500/20",
};


type ComplaintAnalysis = {
  detectedLanguage: "en" | "as" | "other";
  translatedTitle: string;
  summaryEnglish: string;
  summaryAssamese: string;
  category: string;
  priority: "low" | "medium" | "high" | "critical";
  priorityReason: string;
  recommendedDepartment: string;
  locationDetected: string;
  imageFindings: string;
  recommendedAction: string;
  confidence: number;
};

function getComplaintAnalysis(
  value: unknown
): ComplaintAnalysis | null {
  if (!value || typeof value !== "object") return null;
  return value as ComplaintAnalysis;
}


export default function DashboardPage() {
  const router = useRouter();
  const { user, loading } = useAuth();

  const [complaints, setComplaints] = useState<Complaint[]>([]);
  const [fetching, setFetching] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  const [language, setLanguage] = useState<ComplaintLanguage>("en");
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [location, setLocation] = useState("");
  const [image, setImage] = useState<UploadedImage | null>(null);

  // Analysis states of openq
  const [analyzingId, setAnalyzingId] = useState<string | null>(null);
  const [analysisError, setAnalysisError] = useState("");
  const [analysisErrorId, setAnalysisErrorId] = useState<string | null>(null);

  const fetchComplaints = useCallback(async () => {
    if (!auth.currentUser) return;

    setFetching(true);

    try {
      const token = await auth.currentUser.getIdToken();

      const response = await fetch("/api/complaints", {
        headers: {
          Authorization: `Bearer ${token}`,
        },
        cache: "no-store",
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error ?? "Could not load complaints.");
      }

      setComplaints(data.complaints ?? []);
    } catch (err) {
      setError(
        err instanceof Error ? err.message : "Something went wrong."
      );
    } finally {
      setFetching(false);
    }
  }, []);

  useEffect(() => {
    if (!loading && !user) {
      router.replace("/login");
      return;
    }

    if (user) {
      void fetchComplaints();
    }
  }, [user, loading, router, fetchComplaints]);


  async function handleAnalyze(complaintId: string) {
    setAnalysisError("");
    setAnalysisErrorId(null);
    setAnalyzingId(complaintId);

  try {
    const token = await auth.currentUser?.getIdToken();

    if (!token) {
      throw new Error("Please sign in again.");
    }

    const response = await fetch("/api/ai/analyze", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({ complaintId }),
    });

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.error || "AI analysis failed.");
    }

    setComplaints((current) =>
      current.map((item) =>
        item.id === complaintId
          ? {
              ...item,
              aiAnalysis: data.analysis,
              category: data.analysis.category,
              priority: data.analysis.priority,
              department: data.analysis.recommendedDepartment,
            }
          : item
      )
    );
  } catch (err) {
    setAnalysisError(
      err instanceof Error
        ? err.message
        : "Something went wrong during AI analysis."
    );
    setAnalysisErrorId(complaintId);
  } finally {
    setAnalyzingId(null);
  }
}


  async function handleLogout() {
    await signOut(auth);
    router.replace("/login");
  }

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    setError("");
    setSuccess("");
    setSubmitting(true);

    try {
      const token = await auth.currentUser?.getIdToken();

      if (!token) {
        throw new Error("Please sign in again.");
      }

      const response = await fetch("/api/complaints", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          title: title.trim(),
          description: description.trim(),
          language,
          location: location.trim(),
          image,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error ?? "Complaint submission failed.");
      }

      setTitle("");
      setDescription("");
      setLocation("");
      setImage(null);

      setSuccess(
        `Complaint submitted successfully. ID: ${data.complaintId}`
      );

      await fetchComplaints();
    } catch (err) {
      setError(
        err instanceof Error ? err.message : "Something went wrong."
      );
    } finally {
      setSubmitting(false);
    }
  }

  if (loading || !user) {
    return (
      <main className="flex min-h-screen items-center justify-center bg-[#080d18] px-4 text-center text-white">
        <p className="text-sm text-slate-400">
          Loading your dashboard...
        </p>
      </main>
    );
  }

  const stats = {
    total: complaints.length,
    active: complaints.filter(
      (item) =>
        item.status === "submitted" ||
        item.status === "under_review" ||
        item.status === "in_progress"
    ).length,
    resolved: complaints.filter(
      (item) => item.status === "resolved"
    ).length,
  };

  return (
    <main className="min-h-screen overflow-x-hidden bg-[#080d18] text-white">
      {/* Header */}
      <header className="sticky top-0 z-30 border-b border-white/10 bg-[#101827]/95 backdrop-blur-xl">
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-3 px-4 py-3 sm:px-6 lg:px-8">
          <div className="flex min-w-0 items-center gap-3">
            <div className="shrink-0 rounded-xl bg-blue-500/15 p-2.5 text-blue-400">
              <ShieldCheck size={24} />
            </div>

            <div className="min-w-0">
              <h1 className="truncate text-lg font-bold sm:text-xl">
                CivicSense AI
              </h1>
              <p className="text-xs text-slate-400">
                Student portal
              </p>
            </div>
          </div>

          <button
            onClick={handleLogout}
            className="flex shrink-0 items-center gap-2 rounded-lg border border-white/10 px-3 py-2 text-sm text-slate-300 transition hover:bg-white/5 sm:px-4"
          >
            <LogOut size={16} />
            <span className="hidden sm:inline">Logout</span>
          </button>
        </div>
      </header>

      <div className="mx-auto max-w-7xl px-4 py-7 sm:px-6 sm:py-10 lg:px-8">
        {/* Welcome */}
        <section>
          <p className="text-xs font-semibold tracking-[0.2em] text-blue-400 sm:text-sm">
            CIVICSENSE STUDENT PORTAL
          </p>

          <h2 className="mt-3 break-words text-2xl font-bold sm:text-3xl lg:text-4xl">
            Welcome, {user.displayName || "Student"}!
          </h2>

          <p className="mt-2 max-w-2xl text-sm leading-6 text-slate-400 sm:text-base">
            Report campus problems and help make your university better.
          </p>
        </section>

        {/* Statistics */}
        <section className="mt-7 grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3 lg:gap-4">
          <StatCard
            label="Total complaints"
            value={stats.total}
            icon={<FileText size={21} />}
          />

          <StatCard
            label="Active complaints"
            value={stats.active}
            icon={<Clock3 size={21} />}
          />

          <StatCard
            label="Resolved complaints"
            value={stats.resolved}
            icon={<CheckCircle2 size={21} />}
          />
        </section>

        {/* Main content */}
        <div className="mt-8 grid min-w-0 items-start gap-6 lg:grid-cols-2 lg:gap-8">
          {/* Complaint form */}
          <section className="min-w-0 rounded-2xl border border-white/10 bg-[#101827] p-4 sm:p-6 lg:p-7">
            <div className="mb-6 flex items-start gap-3">
              <div className="shrink-0 rounded-xl bg-blue-500/15 p-3 text-blue-400">
                <PlusCircle size={22} />
              </div>

              <div className="min-w-0">
                <h3 className="text-lg font-bold sm:text-xl">
                  Report a campus issue
                </h3>
                <p className="mt-1 text-xs leading-5 text-slate-400 sm:text-sm">
                  Submit your complaint in your preferred language.
                </p>
              </div>
            </div>

            <form onSubmit={handleSubmit} className="space-y-5">
              {/* Language */}
              <div>
                <label className="mb-2 block text-sm font-medium text-slate-300">
                  Complaint language
                </label>

                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => setLanguage("en")}
                    aria-pressed={language === "en"}
                    className={`rounded-xl border p-3 text-sm font-medium transition ${
                      language === "en"
                        ? "border-blue-500 bg-blue-500/10 text-blue-300"
                        : "border-white/10 text-slate-400 hover:bg-white/5"
                    }`}
                  >
                    English
                  </button>

                  <button
                    type="button"
                    onClick={() => setLanguage("as")}
                    aria-pressed={language === "as"}
                    className={`rounded-xl border p-3 text-sm font-medium transition ${
                      language === "as"
                        ? "border-blue-500 bg-blue-500/10 text-blue-300"
                        : "border-white/10 text-slate-400 hover:bg-white/5"
                    }`}
                  >
                    অসমীয়া
                  </button>
                </div>
              </div>

              {/* Title */}
              <div>
                <label
                  htmlFor="complaint-title"
                  className="mb-2 block text-sm font-medium text-slate-300"
                >
                  Complaint title
                </label>

                <input
                  id="complaint-title"
                  required
                  minLength={5}
                  maxLength={120}
                  value={title}
                  onChange={(event) => setTitle(event.target.value)}
                  placeholder={
                    language === "as"
                      ? "সমস্যাটোৰ শিৰোনাম লিখক"
                      : "Enter a short complaint title"
                  }
                  className="w-full min-w-0 rounded-xl border border-white/10 bg-[#080d18] px-4 py-3 text-sm outline-none transition placeholder:text-slate-600 focus:border-blue-500"
                />
              </div>

              {/* Description */}
              <div>
                <label
                  htmlFor="complaint-description"
                  className="mb-2 block text-sm font-medium text-slate-300"
                >
                  Describe the issue
                </label>

                <textarea
                  id="complaint-description"
                  required
                  minLength={10}
                  maxLength={3000}
                  rows={5}
                  value={description}
                  onChange={(event) => setDescription(event.target.value)}
                  placeholder={
                    language === "as"
                      ? "সমস্যাটোৰ বিষয়ে অসমীয়াত লিখক..."
                      : "Explain what happened, where it happened, and how it affects you..."
                  }
                  className="w-full min-w-0 resize-y rounded-xl border border-white/10 bg-[#080d18] px-4 py-3 text-sm leading-7 outline-none transition placeholder:text-slate-600 focus:border-blue-500"
                />

                <p className="mt-1 text-right text-xs text-slate-500">
                  {description.length}/3000
                </p>
              </div>

              {/* Location */}
              <div>
                <label
                  htmlFor="complaint-location"
                  className="mb-2 flex items-center gap-2 text-sm font-medium text-slate-300"
                >
                  <MapPin size={15} />
                  Campus location
                </label>

                <input
                  id="complaint-location"
                  maxLength={200}
                  value={location}
                  onChange={(event) => setLocation(event.target.value)}
                  placeholder={
                    language === "as"
                      ? "স্থান উল্লেখ কৰক (ঐচ্ছিক)"
                      : "e.g. Computer Science Department (optional)"
                  }
                  className="w-full min-w-0 rounded-xl border border-white/10 bg-[#080d18] px-4 py-3 text-sm outline-none transition placeholder:text-slate-600 focus:border-blue-500"
                />
              </div>

              {/* Image upload */}
              <div className="rounded-xl border border-white/10 bg-[#080d18] p-3 sm:p-4">
                <div className="mb-3 flex items-center gap-2">
                  <ImageIcon size={17} className="text-blue-400" />
                  <p className="text-sm font-medium text-slate-300">
                    Attach an image (optional)
                  </p>
                </div>

                <ImageUpload
                  image={image}
                  onImageChange={setImage}
                />
              </div>

              {/* Feedback */}
              {error && (
                <p
                  role="alert"
                  className="break-words rounded-xl border border-red-500/20 bg-red-500/10 p-3 text-sm text-red-300"
                >
                  {error}
                </p>
              )}

              {success && (
                <p
                  role="status"
                  className="break-words rounded-xl border border-emerald-500/20 bg-emerald-500/10 p-3 text-sm text-emerald-300"
                >
                  {success}
                </p>
              )}

              {/* Submit */}
              <button
                type="submit"
                disabled={submitting}
                className="flex w-full items-center justify-center gap-2 rounded-xl bg-blue-600 px-4 py-3.5 text-sm font-semibold transition hover:bg-blue-500 disabled:cursor-not-allowed disabled:opacity-60"
              >
                <Send size={17} />
                {submitting ? "Submitting..." : "Submit complaint"}
              </button>
            </form>
          </section>

          {/* Complaint history */}
          <section className="min-w-0 rounded-2xl border border-white/10 bg-[#101827] p-4 sm:p-6 lg:p-7">
            <div className="mb-6 flex items-center justify-between gap-3">
              <div className="min-w-0">
                <h3 className="text-lg font-bold sm:text-xl">
                  My complaints
                </h3>
                <p className="mt-1 text-xs text-slate-400 sm:text-sm">
                  Track the progress of your reports.
                </p>
              </div>

              <button
                type="button"
                onClick={() => void fetchComplaints()}
                disabled={fetching}
                aria-label="Refresh complaints"
                className="shrink-0 rounded-xl border border-white/10 p-3 text-slate-300 transition hover:bg-white/5 disabled:opacity-50"
              >
                <RefreshCw
                  size={18}
                  className={fetching ? "animate-spin" : ""}
                />
              </button>
            </div>

            {fetching ? (
              <p className="py-12 text-center text-sm text-slate-400">
                Loading complaints...
              </p>
            ) : complaints.length === 0 ? (
              <div className="py-12 text-center">
                <AlertCircle
                  size={35}
                  className="mx-auto text-slate-500"
                />
                <p className="mt-4 font-medium">No complaints yet</p>
                <p className="mt-2 text-sm text-slate-400">
                  Your submitted complaints will appear here.
                </p>
              </div>
            ) : (
              <div className="max-h-[850px] space-y-4 overflow-y-auto pr-1">
                {complaints.map((complaint) => (
                  <article
                    key={complaint.id}
                    className="min-w-0 rounded-xl border border-white/10 bg-[#080d18] p-4 sm:p-5"
                  >
                    <div className="flex flex-wrap items-center justify-between gap-3">
                      <span className="max-w-full break-all text-xs text-slate-500">
                        ID: {complaint.id}
                      </span>

                      <span
                        className={`rounded-full border px-3 py-1 text-xs font-medium ${
                          statusStyles[complaint.status] ??
                          "border-slate-500/20 bg-slate-500/10 text-slate-300"
                        }`}
                      >
                        {statusLabels[complaint.status] ??
                          complaint.status}
                      </span>
                    </div>

                    <h4 className="mt-4 break-words font-semibold">
                      {complaint.title}
                    </h4>

                    <p className="mt-2 whitespace-pre-wrap break-words text-sm leading-6 text-slate-400">
                      {complaint.description}
                    </p>

                    {/* AI analysis controls and result belong inside this complaint card. */}
                    <button
                      type="button"
                      onClick={() => handleAnalyze(complaint.id)}
                      disabled={analyzingId !== null}
                      className="mt-4 flex w-full items-center justify-center gap-2 rounded-xl border border-blue-500/30 bg-blue-500/10 px-4 py-3 text-sm font-semibold text-blue-300 transition hover:bg-blue-500/20 disabled:cursor-not-allowed disabled:opacity-50 sm:w-auto"
                    >
                      <Sparkles
                        size={17}
                        className={
                          analyzingId === complaint.id ? "animate-pulse" : ""
                        }
                      />
                      {analyzingId === complaint.id
                        ? "Analysing complaint..."
                        : getComplaintAnalysis(complaint.aiAnalysis)
                          ? "Re-analyse with AI"
                          : "Analyse with AI"}
                    </button>

                    {analysisError && analysisErrorId === complaint.id && (
                      <p
                        role="alert"
                        className="mt-3 break-words text-sm text-red-400"
                      >
                        {analysisError}
                      </p>
                    )}

                    {getComplaintAnalysis(complaint.aiAnalysis) && (
                      <AnalysisPanel
                        analysis={getComplaintAnalysis(complaint.aiAnalysis)!}
                      />
                    )}

                    {complaint.image?.secureUrl && (
                      <a
                        href={complaint.image.secureUrl}
                        target="_blank"
                        rel="noreferrer"
                        className="mt-4 block"
                      >
                        <img
                          src={complaint.image.secureUrl}
                          alt="Complaint attachment"
                          className="max-h-56 w-full rounded-xl border border-white/10 object-cover sm:max-w-sm"
                        />
                        <span className="mt-2 block text-xs text-blue-400">
                          View attached image
                        </span>
                      </a>
                    )}

                    {complaint.location && (
                      <p className="mt-3 flex items-center gap-2 break-words text-xs text-slate-500">
                        <MapPin size={13} className="shrink-0" />
                        {complaint.location}
                      </p>
                    )}

                    <div className="mt-4 flex flex-wrap items-center justify-between gap-2 border-t border-white/10 pt-4 text-xs text-slate-500">
                      <span>
                        {complaint.language === "as"
                          ? "অসমীয়া"
                          : "English"}
                      </span>

                      <span>
                        {complaint.createdAt
                          ? new Date(
                              complaint.createdAt
                            ).toLocaleString()
                          : "Recently submitted"}
                      </span>
                    </div>
                  </article>
                ))}

              </div>
            )}
          </section>
        </div>
      </div>
    </main>
  );
}

function StatCard({
  label,
  value,
  icon,
}: {
  label: string;
  value: number;
  icon: ReactNode;
}) {
  return (
    <div className="rounded-2xl border border-white/10 bg-[#101827] p-5 sm:p-6">
      <div className="flex items-center justify-between gap-3">
        <p className="text-sm text-slate-400">{label}</p>
        <div className="shrink-0 rounded-xl bg-blue-500/10 p-3 text-blue-400">
          {icon}
        </div>
      </div>

      <p className="mt-5 text-3xl font-bold">{value}</p>
    </div>
  );
}


function AnalysisPanel({
  analysis,
}: {
  analysis: ComplaintAnalysis;
}) {
  const priorityColors: Record<string, string> = {
    low: "text-emerald-300 bg-emerald-500/10",
    medium: "text-blue-300 bg-blue-500/10",
    high: "text-amber-300 bg-amber-500/10",
    critical: "text-red-300 bg-red-500/10",
  };

  const priority = analysis.priority.toLowerCase();

  return (
    <div className="mt-5 space-y-4 rounded-2xl border border-blue-500/20 bg-[#0c1729] p-4 sm:p-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <Sparkles size={19} className="text-blue-400" />
          <h4 className="font-semibold text-white">
            CivicSense AI Analysis
          </h4>
        </div>

        <span
          className={`rounded-full px-3 py-1 text-xs font-semibold uppercase ${
            priorityColors[priority] || "bg-slate-500/10 text-slate-300"
          }`}
        >
          {priority} priority
        </span>
      </div>

      <div className="grid gap-3 sm:grid-cols-2">
        <div className="rounded-xl border border-white/5 bg-white/[0.03] p-3">
          <p className="text-xs text-slate-500">Category</p>
          <p className="mt-1 break-words font-medium capitalize text-slate-200">
            {analysis.category.replaceAll("_", " ")}
          </p>
        </div>

        <div className="rounded-xl border border-white/5 bg-white/[0.03] p-3">
          <p className="text-xs text-slate-500">Recommended department</p>
          <p className="mt-1 break-words font-medium text-slate-200">
            {analysis.recommendedDepartment}
          </p>
        </div>
      </div>

      <div>
        <p className="mb-2 text-xs font-semibold uppercase tracking-wider text-blue-400">
          English summary
        </p>
        <p className="text-sm leading-6 text-slate-300">
          {analysis.summaryEnglish}
        </p>
      </div>

      <div className="rounded-xl border border-white/5 bg-white/[0.03] p-3">
        <p className="mb-2 text-xs font-semibold uppercase tracking-wider text-blue-400">
          অসমীয়া সাৰাংশ
        </p>
        <p
          lang="as"
          className="text-sm leading-7 text-slate-300"
        >
          {analysis.summaryAssamese}
        </p>
      </div>

      <div>
        <p className="text-xs font-semibold text-slate-400">
          Why this priority?
        </p>
        <p className="mt-1 text-sm leading-6 text-slate-300">
          {analysis.priorityReason}
        </p>
      </div>

      {analysis.imageFindings && (
        <div>
          <p className="text-xs font-semibold text-slate-400">
            Image observations
          </p>
          <p className="mt-1 text-sm leading-6 text-slate-300">
            {analysis.imageFindings}
          </p>
        </div>
      )}

      <div>
        <p className="text-xs font-semibold text-slate-400">
          Recommended action
        </p>
        <p className="mt-1 text-sm leading-6 text-slate-300">
          {analysis.recommendedAction}
        </p>
      </div>

      <div className="border-t border-white/10 pt-3">
        <div className="flex items-center justify-between gap-2 text-xs text-slate-500">
          <span>AI confidence estimate</span>
          <span>
            {Math.round(analysis.confidence * 100)}%
          </span>
        </div>

        <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-white/10">
          <div
            className="h-full rounded-full bg-blue-500"
            style={{
              width: `${Math.round(
                analysis.confidence * 100
              )}%`,
            }}
          />
        </div>
      </div>

      <p className="text-xs leading-5 text-slate-500">
        AI-generated recommendations are advisory. University
        administrators must verify findings and approve actions.
      </p>
    </div>
  );
}
